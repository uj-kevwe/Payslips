<?php
// Note: If you have input files large than 200kb we highly recommend to check "async" mode example.

// Get submitted form data
$apiKey = "gfclcodevalley@gmail.com_7b67d821bf3be4cba1dcbd11788a5045a72c9d637e0c9a290606df15d160442954c54e3e";
//$pages = "1";
$pages = "$page_number";
echo $selectedEmail;


// 1. RETRIEVE THE PRESIGNED URL TO UPLOAD THE FILE.
// * If you already have a direct PDF file link, go to the step 3.

// Create URL
/*$url = "https://api.pdf.co/v1/file/upload/get-presigned-url" .
    "?name=" . $_FILES["pdf"]["name"] .
    "&contenttype=application/octet-stream"; */
    
$url = "https://api.pdf.co/v1/file/upload/get-presigned-url" .
    "?name=" . $targetfolder .
    "&contenttype=application/octet-stream";
    
// Create request
$curl = curl_init();
curl_setopt($curl, CURLOPT_HTTPHEADER, array("x-api-key: " . $apiKey));
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
// Execute request
$result = curl_exec($curl);

if (curl_errno($curl) == 0)
{
    $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
    
    if ($status_code == 200)
    {
        $json = json_decode($result, true);
        
        // Get URL to use for the file upload
        $uploadFileUrl = $json["presignedUrl"];
        // Get URL of uploaded file to use with later API calls
        $accessFileUrl = $json["url"];
        
        // 2. UPLOAD THE FILE TO CLOUD.
        
        //$localFile = $_FILES["pdf"]["tmp_name"];
        $localFile = $targetfolder;
        $fileHandle = fopen($localFile, "r");
        
        curl_setopt($curl, CURLOPT_URL, $uploadFileUrl);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array("content-type: application/octet-stream"));
        curl_setopt($curl, CURLOPT_PUT, true);
        curl_setopt($curl, CURLOPT_INFILE, $fileHandle);
        curl_setopt($curl, CURLOPT_INFILESIZE, filesize($localFile));

        // Execute request
        curl_exec($curl);
        
        fclose($fileHandle);
        
        if (curl_errno($curl))
        {
            // Display request error
            echo "<br>Hey1: Error: " . curl_error($curl);
        }
        else
        {
            $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            
            if ($status_code == 200)
            {
                // 3. SPLIT UPLOADED PDF DOCUMENT
                SplitPdf($apiKey, $accessFileUrl, $pages,$selectedEmail);
            }
            else
            {
                // Display service reported error
                echo "<p>Status code: " . $status_code . "</p>"; 
                echo "<p>Hey2: " . $result . "</p>"; 
            }
        }
    }
    else
    {
        // Display service reported error
        echo "<p>Status code: " . $status_code . "</p>"; 
        echo "<p>Hey3: " . $result . "</p>"; 
    }
    
    curl_close($curl);
}
else
{
    // Display CURL error
    echo "Hey 4: Error: " . curl_error($curl);
}


function SplitPdf($apiKey, $fileUrl, $pages,$selectedEmail) 
{
    // Prepare URL for `Split PDF` API call
    $url = "https://api.pdf.co/v1/pdf/split";
        
    // Prepare requests params
    $parameters = array();
    $parameters["name"] = "part.pdf";
    $parameters["url"] = $fileUrl;
    $parameters["pages"] = $pages;

    // Create Json payload
    $data = json_encode($parameters);

    // Create request
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_HTTPHEADER, array("x-api-key: " . $apiKey, "Content-type: application/json"));
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

    // Execute request
    $result = curl_exec($curl);
    
    if (curl_errno($curl) == 0)
    {
        $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        
        if ($status_code == 200)
        {
            $json = json_decode($result, true);
            
            if ($json["error"] == false)
            {
                // Display links to splitted parts
                $resultFiles = $json["urls"];
                foreach ($resultFiles as &$resultFileUrl) {
                    echo "<p><a href=" . $resultFileUrl . ">" . $resultFileUrl . "</a></p>"; 
                    echo $selectedEmail;
                    $mail_message = wordwrap($resultFileUrl,70);
                    mail($selectedEmail,"Splited Pdf", $mail_message);
                }


            }
            else
            {
                // Display service reported error
                echo "<p>Didn't Execute jason_decode</p>";
                echo "<p>Error: " . $json["message"] . "</p>"; 
            }
        }
        else
        {
            // Display request error
            echo "<p>Didn't Execute jason_encode</p>";
            echo "<p>Status code: " . $status_code . "</p>"; 
            echo "<p>" . $result . "</p>"; 
        }
    }
    else
    {
        // Display request error
        echo "<p>Didn't Execute curl_exec function</p>";
        echo "Error: " . curl_error($curl);
    }
    
    // Cleanup
    curl_close($curl);
    
    
}