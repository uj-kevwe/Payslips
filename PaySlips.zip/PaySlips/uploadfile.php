<html>
    <head>
        <title>UBPSSA Upload Status Page</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Payslip Scanner App </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bungee&family=Dancing+Script&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bungee&family=Dancing+Script&display=swap" rel="stylesheet">
        <style>
            .header{
                height:100px;
                top:0;
                left:0;
                width:100%;
                text-align:center;
                position:fixed;
                z-index: 2;
                background: url("Assets/images/uniben.png");
                background-size:8%;
                background-repeat: no-repeat;
                background-color:white;
                background-position:left top;
                background-attachment: fixed;
                padding-top:20px;
            }
            .body{
                margin-top:10px;
                padding: 10% 25% 10% 25%;
                left:0;
                position:relative;
                z-index:1;
                
            }
            .footer{
                height:100px;
                background-color:black;
                color: white;
                bottom: 0;
                position:fixed;
                z-index:2;
                padding-top: 50px;
                padding-left:35%;
                width:100%;
            }
            .footer ul li {
                display: inline-block;
                text-align:center;
            }
        </style>
    </head>

<?php

    /**
     * Split PDF file
     *
     * <p>Split all of the pages from a larger PDF files into
     * single-page PDF files.</p>

     */
    use setasign\Fpdi\Fpdi;
/*    use PHPMailer\PHPMailer;
    use PHPMailer\Exception;
    
    
    require 'Assets/vendor/phpmailer/PHPMailer/src/Exception.php';
    require 'Assets/vendor/phpmailer/PHPMailer/PHPMailer.php';
    require 'Assets/vendor/phpmailer/PHPMailer/src/SMTP.php';
    require 'Assets/PHPMailer/src/Exception.php';
    require 'Assets/PHPMailer/src/PHPMailer.php'; 
    require 'Assets/PHPMailer/src/SMTP.php';*/
    require_once('Assets/fpdi/fpdi/src/autoload.php');
    
    //first move all records on database to historical
    ?>
    <body style = 'background-color:lightgrey; color:blue;'>
        <div class = 'header'>
            <h2>Uniben Batch Payslip Splitter Application</h2>
        </div>
        <div class = 'body'>
            <div style = 'width:100%; display:block;border-style:solid;border-color:blue;text-align:center; background-color:black;'>
                <a href = 'index.php' style='color:white;'>Click on this link to return back to Home Page</a>
            </div>
            <div class='container-fluid'>
                <div class='row'>
                    <div class = 'col-md-6 col-sm-6' style="border-right-style:solid;border-right-width:1px;">
                        <div style="text-decoration:underline"><h4>Staff List Upload Status</h4></div><hr>
                        <?php    
                            include("Assets/include_files/database.php");
                            $movementDate = date("Y-m-d");
                            
                            $sql = "select * from payslipmail";
                            $result = $conn->query($sql);
                            
                            if($result->num_rows>0){
                                while($row = $result->fetch_assoc()){
                                    $payslipDate = date("Y-m-d");
                                    $staffId = $row["StaffID"];
                                    $staffEmail = $row["Email"];
                                    $staffFName = $row["StaffFName"];
                                    $staffSName = $row["StaffSName"];
                                    $sql = "insert into Historical (MovementDate,PayslipDate,StaffID,StaffFName,StaffSName,Email) 
                                            values 
                                            ('$movementDate','$payslipDate','$staffId','$staffFName','$staffSName','$staffEmail')";
                                    $conn->query($sql);
                                    
                                }
                            }
                            //empty payslipmail table
                            $conn->query("delete from payslipmail");
                            
                            //upload new stafflist into payslipmail
                            //$payslipDate = date("d-m-Y");
                            $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 
                            'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 
                            'application/vnd.msexcel', 'text/plain');
                            $fileupload = $_FILES["stafflist"]["tmp_name"];
                            $handle = fopen($fileupload, "r");
                            $c = 1;
                            if(!empty($_FILES['stafflist']['name']) && in_array($_FILES['stafflist']['type'], $csvMimes)){
                                if(is_uploaded_file($fileupload)) {
                                    $count  = 0;
                                    while(($filesop = fgetcsv($handle, 1000, ",")) !== false){
                            		    $count = $count + 1;
                                        $payslipdate = date("Y-m-d");
                                        $sid = $filesop[0];
                                        $sfname = $filesop[1];
                                        $ssname = $filesop[2];
                                        $semail = $filesop[3];
                                        
                                        $sql = "insert into payslipmail(PayslipDate,StaffID,StaffFName,StaffSName, Email) values ('$payslipdate','$sid','$sfname','$ssname','$semail')";
                                        if($result = $conn->query($sql) && $c > 1){
                                            echo $count.")&nbsp;&nbsp;&nbsp;Upload Successful for ".$sid."<br>";
                                        }
                                        else{
                                            if($c > 1){
                                                echo $count.")&nbsp;&nbsp;&nbsp;error uploading Staff ID: ".$sid." with error: ".$conn->error."<br>";
                                            }
                                        }
                                        $c = $c + 1;
                                   }
                                   $conn->query("delete from payslipmail where StaffID = 'StaffId'");
                                   echo "<br><br><br><a href = 'index.php'>Click to return to Home Page</a>";
                                }
                                fclose($handle);
                            }
                        ?>
    
                    </div>
                
                    <div class = 'col-md-6 col-sm-6' style="border-left-style:solid;border-left-width:1px;">
                        <div style="text-decoration:underline"><h4>Payslip Mail Attachment Status</h4></div><hr>
                        <?php
                            $targetfolder = "Assets/Upload/";
                            $targetfolder = $targetfolder . basename( $_FILES['pdf']['name']) ;
                            $ok=1;
                            $file_type=$_FILES['pdf']['type'];
                            if ($file_type=="application/pdf") {
                            	if(!move_uploaded_file($_FILES['pdf']['tmp_name'], $targetfolder)){
                            		//echo "The file ". basename( $_FILES['pdf']['name']). " is uploaded";
                            		echo "<script>
                            				alert('Problem uploading file');
                            				window.location.replace('index.php');
                            			</script>";
                            	}
                            	else {
                            		echo "<script>alert('File Uploaded Successfully');</script>";
                            	} 
                            }
                            else {
                            	echo "<script>
                            			alert('You may only upload PDFs files.')
                            			window.location.replace('index.php');
                            		</script>";
                            }
                            //split_pdf($targetfolder, 'split/');
                            split_pdf($targetfolder, 'split/');
                            
                            function split_pdf($filename, $end_directory = false)
                            {
                                include("Assets/pdf2text/PdfToText.phpclass");
                                include("Assets/include_files/database.php");
                            	require_once('Assets/fpdf/fpdf.php');
                            	require_once('Assets/fpdi/src/Fpdi.php');
                            	
                            	$end_directory = $end_directory ? $end_directory : './';
                            	$new_path = preg_replace('/[\/]+/', '/', $end_directory.'/'.substr($filename, 0, strrpos($filename, '/')));
                            	
                            	if (!is_dir($new_path))
                            	{
                            		// Will make directories under end directory that don't exist
                            		// Provided that end directory exists and has the right permissions
                            		mkdir($new_path, 0777, true);
                            	}
                            	
                            	$pdf = new FPDI();
                            	$pagecount = $pdf->setSourceFile($filename); // How many pages?
                            	
                            	$pdf = new PdfToText( $filename );
                                foreach( $pdf -> Pages as $page_number => $page_contents){
                                    $pages[$page_number] = "$page_contents\n";
                                }
                            	
                            	
                            	// Split each page into a new PDF
                            //	for ($i = 1; $i <= $pagecount; $i++) {
                                $i = 1;
                                foreach( $pdf -> Pages as $page_number => $page_contents){
                            		$new_pdf = new FPDI();
                            		
                            		try {
                            			
                            			//get the email address for this page staffid
                            			$sql = "select * from payslipmail";
                            			$result = $conn->query($sql);
                            			if($result->num_rows>0){
                            			    $count=0;
                            			    while($row = $result->fetch_assoc()){
                            			        $count = $count + 1;
                            			        $staffId = $row["StaffID"];
                            			        $staffEmail = $row["Email"];
                            			        if(strpos($page_contents,$staffId) !== false){
                            			             $new_pdf->AddPage();
                            		                $new_pdf->setSourceFile($filename);
                            		                $new_pdf->useTemplate($new_pdf->importPage($i));
                            		                if(strpos($pages[$i+1],"IPPIS Number:")==false){
                            		                    $new_pdf->AddPage();
                            		                    $new_pdf->setSourceFile($filename);
                            		                    $new_pdf->useTemplate($new_pdf->importPage($i+1));
                            		                }
                            		                $new_filename = $end_directory.str_replace('.pdf', '', $filename).'_'.$i.".pdf";
                            			            $new_pdf->Output($new_filename, "F");
                            			            $pdflink = $new_filename;
                            			        }
                            			        else{
                            			            continue;
                            			        }
                            			        sendPaySlipToEmail($count,$page_number,$staffId,$staffEmail,$pdflink);
                            		            
                            			    }
                            			}
                            		} catch (Exception $e) {
                            			echo 'Caught exception: ',  $e->getMessage(), "\n";
                            		}
                            		$i++;
                            	}
                            }
                            
                            // sendPaySlipToEmail function
                            
                            function sendPaySlipToEmail($c,$pageno,$sid,$email, $link){
                                $file = $link;
                                $base = basename($file);
                                $from = "mygentleflakes@gmail.com";
                                $to = $email;
                                $message = "Find attached your monthly Payslip";
                                $subject = $_POST["mail_subject"];
                                //$file = $temp_name;
                                $content = chunk_split(base64_encode(file_get_contents($file)));
                                $uid = md5(uniqid(time()));
                                $eol = PHP_EOL;
                                $header = "From: ".$from."\r\n";
                                $header .= "MIME-Version: 1.0\r\n";
                                $header .="Content-Type: multipart/mixed; boundary=\"".$uid."\"\r\n";
                                $header .="This is a multi-part message in MIME format.\r\n";
                                $header .= "--".$uid."\r\n";
                                $header .= "Content-type:text/plain; charset=iso-8859-1\r\n";
                                $header .= "Content-type:text/html; charset=iso-8859-1\r\n";
                                $header .= "Content-Transfer-Encoding: 7bit\r\n";
                                $header .= $message. "\r\n";
                                $header .= "--".$uid."\r\n";
                                $header .= "Content-Type: 'pdf' name=\"".$file."\"\r\n";
                                $header .= "Content-Transfer-Encoding: base64\r\n";
                                $header .= "Content-Disposition: attachment; filename=\"".$file."\"\r\n";
                                $header .= $content."\r\n";
                                if(mail($to, $subject, $message, $header)) {
                                   echo $c.")&nbsp;&nbsp;&nbsp;Payslip for ".$sid." Successfully sent to ".$email."<br>";
                                   
                                }else {
                                   echo $c.")&nbsp;&nbsp;&nbsp;Could not send Payslip to ".$email."<br>";
                                   echo error_get_last()['message'];
                                }
                            }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <ul>
                <li>&copy;2022</li>
                <li><a href = "https://gentleflakes.com.ng"><i>powered by https://gentleflakes.com.ng</i></a></li>
            </ul>
        </div>
    </body>
</html>
