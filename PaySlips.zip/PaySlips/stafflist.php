<?php
    include("Assets/include_files/database.php");
    $sql = "select * from Historical order by MovementDate,PayslipDate DESC";
    $result = $conn->query($sql);
    echo "<table class = 'table' style = 'width:100%'>";
    echo "<thead style = 'background-color:white;color:black'>";
    echo "<tr>";
    echo "<td style = 'width:5%'>SNO</td>";
    echo "<td style = 'width:15%'>Movement Date</td>";
    echo "<td style = 'width:15%'>Payslip Date</td>";
    echo "<td style = 'width:8%'>Staff ID</td>";
    echo "<td style = 'width:20%'>First Name</td>";
    echo "<td style = 'width:20%'>Surname</td>";
    echo "<td style = 'width:17%'>Email</td>";
    echo "</tr>";
    echo "</thead>";
    echo "<tbody>";
    if($result->num_rows>0){
        $i = 1;
        while($row = $result->fetch_assoc()){
            $pdate = $row["PayslipDate"];
            $mdate = $row["MovementDate"];
            $sid = $row["StaffID"];
            $sfname = $row["StaffFName"];
            $ssname = $row["StaffSName"];
            $semail = $row["Email"];
            echo "<tr>";
            echo "<td>".$i."</td>";
            echo "<td>".$mdate."</td>";
            echo "<td>".$pdate."</td>";
            echo "<td>".$sid."</td>";
            echo "<td>".$sfname."</td>";
            echo "<td>".$ssname."</td>";
            echo "<td>".$semail."</td>";
            echo "</tr>";
            $i++;
        }
    }
    else{
       echo "<tr>";
            echo "<td>1</td>";
            echo "<td>No Record</td>";
            echo "<td>No Record</td>";
             echo "<td>No Record</td>";
            echo "<td>No Record</td>";
             echo "<td>No Record</td>";
            echo "<td>No Record</td>";
            echo "</tr>"; 
    }
    echo "</tbody>";
    echo "</table>";
?>