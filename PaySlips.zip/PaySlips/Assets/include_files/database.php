<?php

    $server = "localhost";
    $dbusername = "root"; // change this to root (i.e. $dbusername = "root";)
    $dbpassword = ""; // change this to $dbpassword = "";
    $database = "payslipscanner"; //change this to payslipscanner (i.e. $database = "payslipscanner";)

    $conn = new mysqli($server, $dbusername, $dbpassword, $database);

    if($conn->error){
        echo "<script>alert('Error Connecting To Database')</script>";
        echo $conn->error;
    }