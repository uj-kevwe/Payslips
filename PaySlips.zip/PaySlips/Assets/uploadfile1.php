<?php
	include("Assets/pdf2text/PdfToText.phpclass");
	include("Assets/include_files/database.php");
	require('Assets/fpdf/fpdf.php');
	$targetfolder = "Assets/Upload/";
	$targetfolder = $targetfolder . basename( $_FILES['pdf']['name']) ;
	$ok=1;
	$file_type=$_FILES['pdf']['type'];
	if ($file_type=="application/pdf") {
		if(!move_uploaded_file($_FILES['pdf']['tmp_name'], $targetfolder)){
			//echo "The file ". basename( $_FILES['pdf']['name']). " is uploaded";
			echo "<script>
					alert('Problem uploading file');
					window.location.replace('index.php');
				</script>";
		}
		else {
			echo "<script>alert('File Uploaded Successfully');</script>";
		} 
	}
	else {
		echo "<script>
				alert('You may only upload PDFs files.')
				window.location.replace('index.php');
			</script>";
	}
	
	$staffId = array();
    $staffEmail = array();
    $key = 0;
    $sql = "select * from payslipmail";
    $result = $conn->query($sql);
    if($result->num_rows>0){
        while($row = $result->fetch_assoc()){
            $staffId[$key] = $row["StaffID"];
            $staffEmail[$key] = $row["Email"];
            $key++;
        }
    }
    
    

    $pdf = new PdfToText( $targetfolder );
    foreach( $pdf -> Pages as $page_number => $page_contents){
        $pages[$page_number] = "$page_contents\n";
    }
    //convert each page to a pdf file on the server
    $count = count($pages);
    $staffno = count($staffId);
    echo "<br>Number of Payslips: ".$count."<br>";
    echo "<br>Number of Staff: ".$staffno."<br>";
    
    //search for Staff Id match in pdf converted text
    for($i = 0; $i < $staffno;$i++){
        $k = $i + 1;
        echo "<br>Staff No.".$k." ".$staffId[$i];
        //for($j = 1; $j <= $count; $j++){
        foreach( $pdf -> Pages as $page_number => $page_contents){
    /*        echo "<br>Page No.".$j.": ".$pages[$j];
            echo "<br>********************************************";*/
            if(strpos($page_contents,$staffId[$i]) !==false){
                $selectedEmail = $staffEmail[$i];
                echo "<br>Staff Email: ".$selectedEmail;
                echo "<br>Page No.".$page_number."Email: ".$selectedEmail;
                //include("splitpdf.php");
                
                // Note: If you have input files large than 200kb we highly recommend to check "async" mode example.

                // Get submitted form data
                $apiKey = "admin@gentleflakes.com.ng_1fbcf9a0074c8ba644317c9398ecdde28408f2a05d86afa53c20795a4ef5c605a22cc6a5";
                //$pages = "1";
                $next_page = $page_number + 1;
                $pages = "$page_number";
                
                
                // 1. RETRIEVE THE PRESIGNED URL TO UPLOAD THE FILE.
                // * If you already have a direct PDF file link, go to the step 3.
                
                // Create URL
                /*$url = "https://api.pdf.co/v1/file/upload/get-presigned-url" .
                    "?name=" . $_FILES["pdf"]["name"] .
                    "&contenttype=application/octet-stream"; */
                    
                $url = "https://api.pdf.co/v1/file/upload/get-presigned-url" .
                    "?name=" . $targetfolder .
                    "&contenttype=application/octet-stream";
                    
                // Create request
                $curl = curl_init();
                curl_setopt($curl, CURLOPT_HTTPHEADER, array("x-api-key: " . $apiKey));
                curl_setopt($curl, CURLOPT_URL, $url);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                // Execute request
                $result = curl_exec($curl);
                
                if (curl_errno($curl) == 0)
                {
                    $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                    
                    if ($status_code == 200)
                    {
                        $json = json_decode($result, true);
                        
                        // Get URL to use for the file upload
                        $uploadFileUrl = $json["presignedUrl"];
                        // Get URL of uploaded file to use with later API calls
                        $accessFileUrl = $json["url"];
                        
                        // 2. UPLOAD THE FILE TO CLOUD.
                        
                        //$localFile = $_FILES["pdf"]["tmp_name"];
                        $localFile = $targetfolder;
                        $fileHandle = fopen($localFile, "r");
                        
                        curl_setopt($curl, CURLOPT_URL, $uploadFileUrl);
                        curl_setopt($curl, CURLOPT_HTTPHEADER, array("content-type: application/octet-stream"));
                        curl_setopt($curl, CURLOPT_PUT, true);
                        curl_setopt($curl, CURLOPT_INFILE, $fileHandle);
                        curl_setopt($curl, CURLOPT_INFILESIZE, filesize($localFile));
                
                        // Execute request
                        curl_exec($curl);
                        
                        fclose($fileHandle);
                        
                        if (curl_errno($curl))
                        {
                            // Display request error
                            echo "<br>Hey1: Error: " . curl_error($curl);
                        }
                        else
                        {
                            $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
                            
                            if ($status_code == 200)
                            {
                                // 3. SPLIT UPLOADED PDF DOCUMENT
                                SplitPdf($apiKey, $accessFileUrl, $pages,$selectedEmail);
                            }
                            else
                            {
                                // Display service reported error
                                echo "<p>Status code: " . $status_code . "</p>"; 
                                echo "<p>Hey2: " . $result . "</p>"; 
                            }
                        }
                    }
                    else
                    {
                        // Display service reported error
                        echo "<p>Status code: " . $status_code . "</p>"; 
                        echo "<p>Hey3: " . $result . "</p>"; 
                    }
                    
                    curl_close($curl);
                }
                else
                {
                    // Display CURL error
                    echo "Hey 4: Error: " . curl_error($curl);
                }
            } 
        }
    }
    
    
    
    function SplitPdf($apiKey, $fileUrl, $pages,$selectedEmail) 
    {
        // Prepare URL for `Split PDF` API call
        $url = "https://api.pdf.co/v1/pdf/split";
            
        // Prepare requests params
        $parameters = array();
        $parameters["name"] = "payslip.pdf";
        $parameters["url"] = $fileUrl;
        $parameters["pages"] = $pages;
    
        // Create Json payload
        $data = json_encode($parameters);
    
        // Create request
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_HTTPHEADER, array("x-api-key: " . $apiKey, "Content-type: application/json"));
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    
        // Execute request
        $result = curl_exec($curl);
        
        if (curl_errno($curl) == 0)
        {
            $status_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            
            if ($status_code == 200)
            {
                $json = json_decode($result, true);
                
                if ($json["error"] == false)
                {
                    // Display links to splitted parts
                    $resultFiles = $json["urls"];
                    foreach ($resultFiles as &$resultFileUrl) {
                        echo "<p><a href=" . $resultFileUrl . ">" . $resultFileUrl . "</a></p>"; 
                        $headers = "MIME-Version: 1.0" . "\r\n";
                        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                        $mail_message = "Dear Sir/Ma,\n, kindly click on this link below to download your Payslip for this month\n\n\n";
                        $mail_message = $mail_message.$resultFileUrl;
                        $mail_message = wordwrap($mail_message,70);
                        mail($selectedEmail,"Your Payslip Link", $mail_message);
                    }
    
    
                }
                else
                {
                    // Display service reported error
                    echo "<p>Didn't Execute jason_decode</p>";
                    echo "<p>Error: " . $json["message"] . "</p>"; 
                }
            }
            else
            {
                // Display request error
                echo "<p>Didn't Execute jason_encode</p>";
                echo "<p>Status code: " . $status_code . "</p>"; 
                echo "<p>" . $result . "</p>"; 
            }
        }
        else
        {
            // Display request error
            echo "<p>Didn't Execute curl_exec function</p>";
            echo "Error: " . curl_error($curl);
        }
        
        // Cleanup
        curl_close($curl);
        
        
    }
    
?>