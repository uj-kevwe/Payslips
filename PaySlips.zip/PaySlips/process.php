<?php error_reporting('E_NOTICE'); ?>

<?php
//change settings here
$your_email = "uj.kevwe@gmail.com";
$your_smtp = "smtp.gmail.com";
$your_smtp_user = "uj.kevwe@gmail.com";
$your_smtp_pass = "@soeversoever.com";
$your_website = "http://gentleflakes.com.ng";


require("phpmailer/class.phpmailer.php");


//function to check properly formed email address

function isEmailValid($email)
{
  // checks proper syntax
  if( !preg_match( "/^([a-zA-Z0-9])+([a-zA-Z0-9\._-])*@([a-zA-Z0-9_-])+([a-zA-Z0-9\._-]+)+$/", $email))
  {
    return false;
  } 
  
  return true;
  
}


//get contact form details
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$url  = $_POST['url'];
$support = $_POST['support'];


//validate email address, if it is invalid, then returns error
if (!isEmailValid($email)) {
	die('Invalid email address');
}

//start phpmailer code 

$ip = $_SERVER["REMOTE_ADDR"];
$user_agent = $_SERVER['HTTP_USER_AGENT'];



$response="Date: " . date("d F, Y h:i:s A",time()) ."\n" . "IP Address: $ip\nURL: $url\nUser-agent:$user_agent\nName: $name\nEmailaddress:\n$email\n\nPhoneaddress:\n$phone\n\nContents:\n$support\n";
//mail("info@mypapit.net","Contact form fakapster",$response, $headers);

$mail = new PHPmailer();
$mail->SetLanguage("en", "phpmailer/language");

$mail->From = $your_email;
$mail->FromName = $your_website;
$mail->Host = $your_smtp;
$mail->Mailer   = "smtp";
$mail->Password = $your_smtp_pass;
$mail->Username = $your_smtp_user;
$mail->Subject = "MONTHLY PAYSLIP";
$mail->SMTPAuth  =  "true";

$mail->Body = $response;
$mail->AddAddress($your_email,"Admin");
$mail->AddReplyTo($email,$name);


if (!$mail->Send()) {
echo "<p>There was an error in sending mail, please try again at a later time</p>";
echo "<p>".$mail->ErrorInfo."</p>";
} else {
	echo "<p><center>Thanks for your feedback, <em>$name</em>! We will contact you soon!</center></p>";
}

$mail->ClearAddresses();
$mail->ClearAttachments();

?>