<?php
    include("Assets/include_files/database.php");
    if($_GET["type"]=="indv"){
        $sid = $_POST["delStaffId"];
        $sql = "delete from payslipmail where StaffID = '$sid'";
        if($result = $conn->query($sql)){
            echo "<script>
                    alert('Staff Removed Successfully');
                    window.location.replace('index.php');
                </script>";
        }
        else{
            echo "<script>
                alert('Error removing Staff ID');
                window.location.replace('index.php');
            </script>";
        }
    }
    else if($_GET["type"] == "batch"){
        $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 
        'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 
        'application/vnd.msexcel', 'text/plain');
        $batchdel = $_FILES["batchDelFile"]["tmp_name"];
        $handle = fopen($batchdel, "r");
        $c = 1;
        if(!empty($_FILES['batchDelFile']['name']) && in_array($_FILES['batchDelFile']['type'], $csvMimes)){
            if(is_uploaded_file($batchdel)) {
                while(($filesop = fgetcsv($handle, 1000, ",")) !== false){
                    $sid = $filesop[0];
                    $semail = $filesop[1];
                    $sql = "delete from payslipmail where StaffID = '$sid'";
                    if($result = $conn->query($sql) && $c > 1){
                        echo "<br>Deletion Successful for ".$sid;    
                    }
                    else{
                        echo "<br>error deleting StaffID: ".$sid." with error: ".$conn->error;
                    }
                    $c = $c + 1;
               }
               echo "<br><br><br><a href = 'index.php'>Click to return to Home Page</a>";
            }
            fclose($handle);
        }
    }
?>