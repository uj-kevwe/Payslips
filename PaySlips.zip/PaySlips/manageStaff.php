<?php
    //print_r($_POST);
    include("Assets/include_files/database.php");
    if(isset($_POST["submitStaff"])){
        $staffId = $_POST["staffId"];
        $staffEmail = $_POST["staffEmail"];
        $sql = "insert into payslipmail (StaffID, Email) values ('$staffId','$staffEmail')";
        if($result = $conn->query($sql)){
            echo "<script>
                    alert('New Staff Added Successfully');
                    window.location.replace('index.php');
                </script>";
        }
        else{
            echo "<script>
                    alert('Could not Add Staff Successfully');
                    window.location.replace('index.php');
                </script>";
        }
    }
    else if(isset($_POST["submitBatchAdd"])){
        $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 
        'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 
        'application/vnd.msexcel', 'text/plain');
        $fileupload = $_FILES["batchAddFile"]["tmp_name"];
        $handle = fopen($fileupload, "r");
        $c = 1;
        if(!empty($_FILES['batchAddFile']['name']) && in_array($_FILES['batchAddFile']['type'], $csvMimes)){
            if(is_uploaded_file($fileupload)) {
                while(($filesop = fgetcsv($handle, 1000, ",")) !== false){
                    $sid = $filesop[0];
                    $semail = $filesop[1];
                    $sql = "insert into payslipmail(StaffID,Email) values ('$sid','$semail')";
                    if($result = $conn->query($sql) && $c > 1){
                        echo "<br>Upload Successful for ".$sid;
                    }
                    else{
                        if($c > 1){
                            echo "<br>error uploading Staff ID: ".$sid." with error: ".$conn->error;
                        }
                    }
                    $c = $c + 1;
               }
               $conn->query("delete from payslipmail where StaffID = 'StaffId'");
               echo "<br><br><br><a href = 'index.php'>Click to return to Home Page</a>";
            }
            fclose($handle);
        }
        include ("uploadfile.php");
    }
    else if(isset($_POST["submitDelStaff"])){
        $sid = $_POST["delStaffId"];
        $sql = "delete from payslipmail where StaffID = '$sid'";
        if($result = $conn->query($sql)){
            echo "<script>
                    alert('Staff Removed Successfully');
                    window.location.replace('index.php');
                </script>";
        }
        else{
            echo "<script>
                    alert('Error removing Staff ID');
                    window.location.replace('index.php');
                </script>";
        }
    }
    else if(isset($_POST["submitBatchDel"])){
        $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 
        'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 
        'application/vnd.msexcel', 'text/plain');
        $batchdel = $_FILES["batchDelFile"]["tmp_name"];
        $handle = fopen($batchdel, "r");
        $c = 1;
        if(!empty($_FILES['batchDelFile']['name']) && in_array($_FILES['batchDelFile']['type'], $csvMimes)){
            if(is_uploaded_file($batchdel)) {
                while(($filesop = fgetcsv($handle, 1000, ",")) !== false){
                    $sid = $filesop[0];
                    $semail = $filesop[1];
                    $sql = "delete from payslipmail where StaffID = '$sid'";
                    if($result = $conn->query($sql) && $c > 1){
                        echo "<br>Deletion Successful for ".$sid;    
                    }
                    else{
                        echo "<br>error deleting StaffID: ".$sid." with error: ".$conn->error;
                    }
                    $c = $c + 1;
               }
               echo "<br><br><br><a href = 'index.php'>Click to return to Home Page</a>";
            }
            fclose($handle);
        }
    }
    else if(isset($_POST["viewStaffList"])){
        $sql = "select * from payslipmail";
        $result = $conn->query($sql);
        if($result->num_rows>0){
            echo "<table class='table'>";
            while($row = $result->fetch_assoc()){
                $sid = $row["StaffID"];
                $semail = $row["Email"];
                echo "<tr>";
                echo "<td>'$sid'</td>";
                echo "<td>'$semail'</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    }
?>