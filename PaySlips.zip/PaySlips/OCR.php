<?php

namespace myBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

// Include the Tesseract Wrapper 
use TesseractOCR;

class DefaultController extends Controller
{
    public function indexAction()
    {
        // Retrieve the webpath in symfony
        $webPath = $this->get('kernel')->getRootDir().'Assets/Upload/';
        // The filename of the image is text.jpeg and is located inside the web folder
        $filepath = $webPath.'HTML.pdf';

        // Is useful to verify if the file exists, because the tesseract wrapper
        // will throw an error but without description
        if(!file_exists($filepath)){
            return new Response("Warning: the providen file [".$filepath."] doesn't exists.");
        }

        // Create a  new instance of tesseract and provide as first parameter
        // the local path of the image
        $tesseractInstance = new TesseractOCR($filepath);

        // Execute tesseract to recognize text
        $result = $tesseractInstance->run();

        // Return the recognized text as response (expected: The quick brown fox jumps over the lazy dog.)
        return new Response($result);
    }
}