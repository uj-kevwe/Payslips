<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Payslip Scanner App </title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bungee&family=Dancing+Script&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Audiowide">
        <link rel="stylesheet" href="assets/css/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Bungee&family=Dancing+Script&display=swap" rel="stylesheet">
        <style>
            .body{
                left:0;
                position:relative;
                z-index:1;
                text-align:center;
                padding:20% 20% 20% 20%;
            }
            .header{
                height:100px;
                top:0;
                left:0;
                width:100%;
                position:fixed;
                z-index: 2;
                background: url("Assets/images/uniben.png");
                background-size:8%;
                background-repeat: no-repeat;
                background-color:white;
                background-position:left top;
                background-attachment: fixed;
                padding-top:20px;
            }
            .header h2{
                text-align:center;
            }
            form h4{
                text-align:center;
            }
            label h4{
                margin:0;
            }
            #batch{
                background-color:blue;
                color:white;
                padding:1% 10% 10% 10%;
                line-height:3;
                border-style:solid;
                border-color:lightgrey;
                border-radius:5%;
                border-width:5px;
            }
            #manageStaff input[type=button]{
                width:100%;
                color:black;
                text-align:left;
            }
            #addStaffById, #addStaffByBatch, #deleteStaffById, #deleteStaffByBatch, #viewStaff{
                width:100%;
                display:none;
            }
            label #staffId, #staffEmail{
                width:100%;
            }
            input[type = "submit"]{
                margin:auto;
                display:block;
            }
            #upload{
                background-color:white;
                padding:8%;
            }
            #manageStaff{
                padding: 5%; 2% 20% 2%;
            }

            #manageStaff, #upload{
                display:none;
                border-style:solid;
                border-width:1px;
                border-color:white;
            }
            #staffing{
                border-style:solid;
                border-color:white;
            }
            #staffview{
                max-height:200px;
                overflow-y:scroll;
            }
            @media only screen and (max-width:900px){
                .body{
                    padding: 55% 5% 25% 5%;
                    margin-top:10px;
                }
                .header{
                    background-position: center top;
                    background-size:40%;
                    padding-top:30%;
                    text-align:right;
                }
                #viewStaffList{
                    width:80%;
                    word-wrap:break-word;
                }
            }
        </style>
        <script>
            function pickOption(){
                if(document.getElementById("manageStaffCheck").checked==true){
                    document.getElementById("manageStaff").style.display = "block";
                    document.getElementById("upload").style.display = "none";
                    document.getElementById("viewStaff").style.display = "none";
                }
                else if(document.getElementById("addUpload").checked==true){
                    document.getElementById("manageStaff").style.display = "none";
                    document.getElementById("upload").style.display = "block"; 
                    document.getElementById("viewStaff").style.display = "none";
                }
            }
            function showManage(x){
                switch(x){
                    case "Add Staff By ID":
                        /*alert ("Add An Individual Staff");*/
                        document.getElementById("addStaffById").style.display = "block";
                        document.getElementById("addStaffByBatch").style.display = "none";
                        document.getElementById("deleteStaffById").style.display = "none";
                        document.getElementById("deleteStaffByBatch").style.display = "none";
                        document.getElementById("viewStaff").style.display = "none";
                        document.getElementById("staffview").style.display = "none";
                        break;
                    case "Add Staff By BATCH FILE (.csv)":
                        /*alert ("Add Staff By Batch. Load (.csv excel file)");*/
                        document.getElementById("addStaffById").style.display = "none";
                        document.getElementById("addStaffByBatch").style.display = "block";
                        document.getElementById("deleteStaffById").style.display = "none";
                        document.getElementById("deleteStaffByBatch").style.display = "none";
                        document.getElementById("viewStaff").style.display = "none";
                        document.getElementById("staffview").style.display = "none";
                        break;
                    case "Delete Staff By ID":
                        /*alert ("Delete An Individual Staff");*/
                        document.getElementById("addStaffById").style.display = "none";
                        document.getElementById("addStaffByBatch").style.display = "none";
                        document.getElementById("deleteStaffById").style.display = "block";
                        document.getElementById("deleteStaffByBatch").style.display = "none";
                        document.getElementById("viewStaff").style.display = "none";
                        document.getElementById("staffview").style.display = "none";
                        break;
                    case "Delete Staff By BATCH FILE (.csv)":
                        /*alert ("Delete Individual Staff By Batch Upload (.csv excel file)");*/
                        document.getElementById("addStaffById").style.display = "none";
                        document.getElementById("addStaffByBatch").style.display = "none";
                        document.getElementById("deleteStaffById").style.display = "none";
                        document.getElementById("deleteStaffByBatch").style.display = "block";
                        document.getElementById("viewStaff").style.display = "none";
                        document.getElementById("staffview").style.display = "none";
                        break;
                    case "View Staff":
                       /* alert("View All Staff ID and Emails");*/
                        document.getElementById("addStaffById").style.display = "none";
                        document.getElementById("addStaffByBatch").style.display = "none";
                        document.getElementById("deleteStaffById").style.display = "none";
                        document.getElementById("deleteStaffByBatch").style.display = "none";
                        document.getElementById("viewStaff").style.display = "block";
                        document.getElementById("staffview").style.display = "none";
                        break;
                }
            }
            
            function loadStaff(){
                /*alert("Fetching Staff Data");*/
                const xhttp = new XMLHttpRequest();
                xhttp.onload = function() {
                    document.getElementById("staffview").innerHTML = this.responseText;
                    document.getElementById("staffview").style.display = "block";
                }
                xhttp.open("GET", "stafflist.php");
                xhttp.send();
            }
        </script>
    </head>
    <body>
        <div class="header">
            <h2>University of Benin Batch Payslip Splitter </h2>
        </div>
        <div class = "body">
            <div class="container-fluid" id="batch" style="">
                <div class = "row">
                    <h2 style="font-family: 'Bungee', cursive;">UBPSA</h2>
                    <hr>
                    <label style = "width: 150px;padding:10px; margin:10px;background-color:lightgrey;color:blue;">
                        <input type="radio" name="chooseOption" id="manageStaffCheck" value = "manageStaff" onclick="pickOption();">
                        Manage Staff
                    </label>
                    <label style = "width: 150px;padding:10px; margin:10px;background-color:lightgrey;color:blue;">
                        <input type="radio" name="chooseOption" id="addUpload" value = "upload"  onclick="pickOption();">
                        Upload Pdf
                    </label>
                </div>
                <div class="row" id="staffing">
                    <div class = "col-md-5">
                        <div id = "manageStaff">
                            <input type = "button" value = "Add Staff By ID" onclick = "showManage(this.value)">
                            <input type = "button" value = "Add Staff By BATCH FILE (.csv)" onclick = "showManage(this.value)">
                            <input type = "button" value = "Delete Staff By ID" onclick = "showManage(this.value)">
                            <input type = "button" value = "Delete Staff By BATCH FILE (.csv)" onclick = "showManage(this.value)">
                            <input type = "button" value = "View Staff" onclick = "showManage(this.value)">
                        </div>
                    </div>
                    <div class = "col-md-7">
                        <form action="manageStaff.php" method="post">
                            <div id="addStaffById">
                                <label style="width:100%">
                                    <input class="form-control" type = "text" id = "staffId" name = "staffId" placeholder = "New Staff ID">
                                </label><br>
                                <label style="width:100%">
                                    <input class="form-control" type = "email" id = "staffEmail" name = "staffEmail" placeholder = "New Staff Email">
                                </label><br><br>
                                <input class="btn btn-info" type="submit" name="submitStaff" id="submitStaff" value="Add Staff">
                            </div>
                        </form>
                        <form action = "manageStaff.php" method = "post" enctype="multipart/form-data">
                            <div id = "addStaffByBatch">
                                <label style="width:100%">
                                    Upload an Excel CSV File (.csv only)
                                    <input class="form-control" type = "file" id = "batchAddFile" name = "batchAddFile">
                                </label><br>
                                <input class="btn btn-info" type="submit" name="submitBatchAdd" id="submitBatchAdd" value="Upload Batch Staff">
                            </div>
                        </form>
                        <form action = "manageStaff.php" method = "post">
                            <div id = "deleteStaffById">
                                <label style="width:100%">
                                    <input class="form-control" type = "text" id = "delStaffId" name = "delStaffId" placeholder = "Staff ID To Delete">
                                </label><br>
                                <input class="btn btn-info" type="submit" name="submitDelStaff" id="submitDelStaff" value="Delete Staff">
                            </div>
                        </form>
                        <form action = "manageStaff.php" method = "post" enctype="multipart/form-data">
                            <div id = "deleteStaffByBatch">
                                <label style="width:100%">
                                    Upload an Excel CSV File (.csv only)
                                    <input class="form-control" type = "file" id = "batchDelFile" name = "batchDelFile">
                                </label><br>
                                <input class="btn btn-info" type="submit" name="submitBatchDel" id="submitBatchDel" value="Delete Batch Staff">
                            </div>
                        </form>
                    <!--    <form action = "manageStaff.php" method = "post" > -->
                            <div id = "viewStaff">
                                <input class="btn btn-info" type="button" name="viewStaffList" id="viewStaffList" 
                                value="View All Staff ID and Emails" onclick = "loadStaff();">
                                <div id="staffview">
                                    
                                </div>
                            </div>
                    <!--    </form> -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <form id="uploadform" action="uploadfile.php" method="post" enctype="multipart/form-data">
                            <div id="upload">
                                <input class="form-control"  type="text" name="mail_subject" id="mail_subject" 
                                placeholder = "Indicate a Subject/Title for the Payslip  Mails"><br>
                                <input class="form-control"  type="file" name="pdf" id="pdf"><br><br>
                                <input class="btn btn-info" type="submit" name="submitPdf" id="submitPdf" value="Upload Batch Pdf">
                            </div>  
                        </form>
                    </div>
                </div>
            </div>
            <?php
            
            ?>
        </div>
    </body>
</html>